<?php
namespace App\EventSubscriber;

use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class ApiTokenListener implements EventSubscriberInterface
{
    private Session $session;
    private UrlGeneratorInterface $urlGenerator;
    private $routesRequiringToken;

    public function __construct(
        Session $session,
        UrlGeneratorInterface $urlGenerator,
        array $routesRequiringToken = [
            'app_authors',
            'view_author',
            'delete_author',
            'app_books',
            'add_book',
            'create_book',
            'delete_book',
            'user_profile',
            'app_logout'
        ]
    )
    {
        $this->session = $session;
        $this->urlGenerator = $urlGenerator;
        $this->routesRequiringToken = $routesRequiringToken;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::REQUEST => 'onKernelRequest',
        ];
    }

    public function onKernelRequest(RequestEvent $event): void
    {
        $request = $event->getRequest();
        $routeName = $request->attributes->get('_route');

        if (in_array($routeName, $this->routesRequiringToken) && !$this->session->get('api_token')) {
            $event->setResponse(new RedirectResponse($this->urlGenerator->generate('app_home')));
        }

        if (!in_array($routeName, $this->routesRequiringToken) && $this->session->get('api_token')) {
            $event->setResponse(new RedirectResponse($this->urlGenerator->generate('app_authors')));
        }
    }
}
