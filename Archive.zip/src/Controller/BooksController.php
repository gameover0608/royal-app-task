<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class BooksController extends AbstractController
{
    private HttpClientInterface $apiClient;
    private SessionInterface $session;

    public function __construct(HttpClientInterface $apiClient, SessionInterface $session)
    {
        $this->apiClient = $apiClient;
        $this->session = $session;
    }

    public function get(int $id) {
        try {
            $response = $this->apiClient->request('GET', 'https://symfony-skeleton.q-tests.com/api/v2/authors/'.$id , [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->session->get('api_token'),
                ],
            ]);
            return json_decode($response->getContent(), true)['books'];
        } catch (TransportExceptionInterface | RedirectionExceptionInterface | ServerExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'dsa' => 'dad', 'message' => $e->getMessage()]);
        } catch (ClientExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'message' => 'Wrong Credentials', 'exception' => $e->getMessage()]);
        }
    }

    #[Route('/books/add', name: 'add_book')]
    public function add() {
        $authorsController = new AuthorsController($this->apiClient, $this->session);

        $authors = $authorsController->get();

        return $this->render('books/add-book.twig', [
            'authors' => $authors,
        ]);
    }

    #[Route('/books/create', name: 'create_book')]
    public function create(Request $request) {
        $data = $request->request->all();

        $dateTime = new \DateTime($data['release_date']);
        $formatter = new \IntlDateFormatter('en', \IntlDateFormatter::FULL, \IntlDateFormatter::FULL);
        $formatter->setPattern('yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'');
        $formattedDateStr = $formatter->format($dateTime);

        $data['release_date'] = $formattedDateStr;
        $data['isbn'] = 'test';
        $data['number_of_pages'] = intval($data['number_of_pages']);
        try {
            $this->apiClient->request('POST', 'https://symfony-skeleton.q-tests.com/api/v2/books', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->session->get('api_token'),
                ],
                'json' => $data,
            ]);

            return $this->redirectToRoute('view_author', ['id' => $data['author']['id']]);
        } catch (TransportExceptionInterface | RedirectionExceptionInterface | ServerExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'message' => $e->getMessage()]);
        } catch (ClientExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'exception' => $e->getMessage()]);
        }
    }

    #[Route('/books/{id}', name: 'delete_book')]
    public function delete(int $id) {
        try {
            $this->apiClient->request('DELETE', 'https://symfony-skeleton.q-tests.com/api/v2/books/'.$id , [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->session->get('api_token'),
                ],
            ]);
            return $this->redirectToRoute('app_authors');
        } catch (TransportExceptionInterface | RedirectionExceptionInterface | ServerExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'message' => $e->getMessage()]);
        } catch (ClientExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'exception' => $e->getMessage()]);
        }
    }
}
