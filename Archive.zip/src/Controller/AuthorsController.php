<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class AuthorsController extends AbstractController
{

    private HttpClientInterface $apiClient;
    private SessionInterface $session;

    public function __construct(HttpClientInterface $apiClient, SessionInterface $session)
    {
        $this->apiClient = $apiClient;
        $this->session = $session;
    }

    #[Route('/authors', name: 'app_authors')]
    public function index(): Response
    {
        // Fetch the list of authors from the API
        try {
            $authors = $this->get();

            $booksController = new BooksController($this->apiClient, $this->session);
            foreach ($authors as $key => $author) {
                $books = $booksController->get($author['id']);
                if (empty($books)) {
                    $authors[$key]['canDelete'] = true;
                }
            }

            return $this->render('authors/index.html.twig', [
                'authors' => $authors,
            ]);
        } catch (TransportExceptionInterface | RedirectionExceptionInterface | ServerExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'dsa' => 'dad', 'message' => $e->getMessage()]);
        } catch (ClientExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'message' => 'Wrong Credentials', 'exception' => $e->getMessage()]);
        }

    }

    public function get() {
        try {
            $response = $this->apiClient->request('GET', 'https://symfony-skeleton.q-tests.com/api/v2/authors', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->session->get('api_token'),
                ],
            ]);

            return json_decode($response->getContent(), true)['items'];
        } catch (TransportExceptionInterface | RedirectionExceptionInterface | ServerExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'dsa' => 'dad', 'message' => $e->getMessage()]);
        } catch (ClientExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'message' => 'Wrong Credentials', 'exception' => $e->getMessage()]);
        }
    }

    #[Route('/authors/{id}', name: 'view_author')]
    public function show(int $id): Response {
        $booksController = new BooksController($this->apiClient, $this->session);
        $books = $booksController->get($id);

        return $this->render('authors/view-author.twig', [
            'books' => $books,
        ]);
        //return new JsonResponse(['success' => true, 'books' => $books, 'message' => 'Logged in successfully']);

    }

    #[Route('delete/authors/{id}', name: 'delete_author')]
    public function delete(int $id):Response {
        // Fetch the list of authors from the API
        try {
            $this->apiClient->request('DELETE', 'https://symfony-skeleton.q-tests.com/api/v2/authors/'.$id , [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->session->get('api_token'),
                ],
            ]);
            return $this->redirectToRoute('app_authors');
        } catch (TransportExceptionInterface | RedirectionExceptionInterface | ServerExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'dsa' => 'dad', 'message' => $e->getMessage()]);
        } catch (ClientExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'message' => 'Wrong Credentials', 'exception' => $e->getMessage()]);
        }
    }
}
