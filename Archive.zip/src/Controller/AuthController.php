<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Component\HttpFoundation\JsonResponse;

class AuthController extends AbstractController
{

    private HttpClientInterface $apiClient;
    private SessionInterface $session;

    public function __construct(HttpClientInterface $apiClient, SessionInterface $session)
    {
        $this->apiClient = $apiClient;
        $this->session = $session;
    }

    #[Route('/login', name: 'app_auth')]
    public function login(Request $request)
    {
        $email = $request->request->get('email');
        $password = $request->request->get('password');

        // Validate the username and password
        if ($email && $password) {
            try {
                $response = $this->apiClient->request('POST', 'https://symfony-skeleton.q-tests.com/api/v2/token', [
                    'json' => [
                        'email' => $email,
                        'password' => $password,
                    ],
                ]);
                $token = json_decode($response->getContent(), true)['token_key'];
                $this->session->set('api_token', $token);

                return $this->redirectToRoute('user_profile');
            } catch (TransportExceptionInterface | RedirectionExceptionInterface | ServerExceptionInterface $e) {
                return new JsonResponse(['success' => false, 'message' => $e->getMessage()]);
            } catch (ClientExceptionInterface $e) {
                return new JsonResponse(['success' => false, 'exception' => $e->getMessage()]);
            }

        } else {
            return new JsonResponse(['success' => false, 'message' => 'Invalid credentials']);
        }
    }

    #[Route('/logout', name: 'app_logout')]
    public function logout() {
        $this->session->clear();
        return $this->redirectToRoute('app_home');
    }
}
