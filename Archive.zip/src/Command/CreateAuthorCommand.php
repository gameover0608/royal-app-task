<?php

namespace App\Command;

use DateTimeImmutable;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class CreateAuthorCommand extends Command
{
    private HttpClientInterface $apiClient;

    public function __construct(HttpClientInterface $apiClient)
    {
        $this->apiClient = $apiClient;

        parent::__construct();
    }

    protected function configure()
    {
        $this
            ->setName('app:create-author')
            ->setDescription('Create a new author via the API')
            ->addArgument('first_name', InputArgument::REQUIRED, 'The first name of the author')
            ->addArgument('last_name', InputArgument::REQUIRED, 'The last name of the author')
            ->addArgument('birthday', InputArgument::REQUIRED, 'The birthday of the author')
            ->addArgument('biography', InputArgument::REQUIRED, 'The biography of the author')
            ->addArgument('gender', InputArgument::REQUIRED, 'The gender of the author')
            ->addArgument('place_of_birth', InputArgument::REQUIRED, 'The place of birth of the author')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        // Fetch the name and email arguments from the command line
        $data = [];
        $data['first_name'] = $input->getArgument('first_name');
        $data['last_name'] = $input->getArgument('last_name');
        $data['birthday'] = $input->getArgument('birthday');
        $data['biography'] = $input->getArgument('biography');
        $data['gender'] = $input->getArgument('gender');
        $data['place_of_birth'] = $input->getArgument('place_of_birth');

        $date = new DateTimeImmutable($data['birthday']);
        $formatter = new \IntlDateFormatter('en', \IntlDateFormatter::FULL, \IntlDateFormatter::FULL);
        $formatter->setPattern('yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'');
        $data['birthday'] = $formatter->format($date);

        try {
            // Send a POST request to the API to create a new author
            $token = $this->getApiToken();
            $response = $this->apiClient->request('POST', 'https://symfony-skeleton.q-tests.com/api/v2/authors', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                ],
                'json' => $data,
            ]);
            $author = json_decode($response->getContent(), true);

            // Output a success message with the new author's ID
            $output->writeln('Author created with ID: ' . $author['id']);

            return Command::SUCCESS;
        } catch (TransportExceptionInterface | RedirectionExceptionInterface | ServerExceptionInterface $e) {
            $output->writeln('Error:'. $e->getMessage());
            return Command::FAILURE;
        } catch (ClientExceptionInterface $e) {
            $output->writeln('Error Client:'. $e->getMessage());
            return Command::FAILURE;
        }
    }

    private function getApiToken() {
        try {
            $response = $this->apiClient->request('POST', 'https://symfony-skeleton.q-tests.com/api/v2/token', [
                'json' => [
                    'email' => 'ahsoka.tano@q.agency',
                    'password' => 'Kryze4President',
                ],
            ]);

            return json_decode($response->getContent(), true)['token_key'];

        } catch (TransportExceptionInterface | RedirectionExceptionInterface | ServerExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'dsa' => 'dad', 'message' => $e->getMessage()]);
        } catch (ClientExceptionInterface $e) {
            return new JsonResponse(['success' => false, 'message' => 'Wrong Credentials', 'exception' => $e->getMessage()]);
        }
    }
}
